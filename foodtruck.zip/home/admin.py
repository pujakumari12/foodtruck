from django.contrib import admin
from home.models import FoodTrucks



admin.site.register(FoodTrucks)

